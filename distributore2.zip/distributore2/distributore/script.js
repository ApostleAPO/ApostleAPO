document.addEventListener('DOMContentLoaded', () => {

    // ------ Inizio blocco da incollare/sostituire ------

// VALORI e PORTAFOGLIO INIZIALE (chiavi come stringhe per coerenza)
const MONETE = [2.00, 1.00, 0.50, 0.20, 0.10, 0.05];
let portafoglio = {
  "2": 3,
  "1": 4,
  "0.5": 5,
  "0.2": 6,
  "0.1": 8,
  "0.05": 10
};

let currentCredit = 0.00;
let currentSelection = "";
let messageTimer = null;

// ELEMENTI DOM (assicurati che esistano questi id nel tuo HTML)
const creditDisplay = document.getElementById('credit-display');
const messageDisplay = document.getElementById('message-display');
const dettagliPortafoglio = document.getElementById('dettagli-portafoglio');
const saldoUtenteEl = document.getElementById('saldo-utente');
const dispenserBin = document.getElementById('dispenser-bin');
const coinReturnButton = document.getElementById('coin-return');
const keypad = document.getElementById('keypad');

// aggiornamento display principale
function updateDisplay() {
  creditDisplay.textContent = `€${currentCredit.toFixed(2)}`;
  messageDisplay.textContent = currentSelection || '--';
}

// mostra messaggio temporaneo
function showMessage(msg, duration = 1500) {
  clearTimeout(messageTimer);
  messageDisplay.textContent = msg;
  messageTimer = setTimeout(updateDisplay, duration);
}

// aggiorna portafoglio e saldo a video
function aggiornaPortafoglio() {
  // costruisco dettagli e calcolo totale
  let totale = 0;
  let html = '';

  // itero MONETE in ordine decrescente per visualizzazione
  for (const v of MONETE) {
    const key = String(v).replace(/\.0+$/,''); // es. 1.0 -> "1"
    // normalizzo per 0.5 ecc
    const keyExact = (v % 1 === 0) ? String(v).replace('.0','') : String(v);
    // preferisco usare stringa con decimale per 0.5 e 0.05
    const keyUse = (keyExact === '1') ? '1' :
                   (keyExact === '2') ? '2' :
                   (v === 0.5) ? '0.5' :
                   (v === 0.2) ? '0.2' :
                   (v === 0.1) ? '0.1' :
                   (v === 0.05) ? '0.05' : String(v);

    const count = portafoglio[keyUse] || 0;
    totale += v * count;
    html += `€${v.toFixed(2)} × ${count}<br>`;

    // disabilita il pulsante corrispondente (se presente)
    const btn = document.querySelector(`.pulsante-moneta[data-valore="${v.toFixed(2)}"]`);
    if (btn) btn.disabled = (count === 0);
  }

  dettagliPortafoglio.innerHTML = html;
  if (saldoUtenteEl) saldoUtenteEl.textContent = `Saldo: €${totale.toFixed(2)}`;
}

// funzione che rimuove una moneta dal portafoglio e aumenta il credito
function inserisciMonetaByValue(valore) {
  // normalizza key come in portafoglio
  const key = (valore === 2.00) ? '2'
            : (valore === 1.00) ? '1'
            : (valore === 0.5) ? '0.5'
            : (valore === 0.20) ? '0.2'
            : (valore === 0.10) ? '0.1'
            : (valore === 0.05) ? '0.05'
            : String(valore);

  const q = portafoglio[key] || 0;
  if (q <= 0) {
    showMessage(`Non hai monete da €${valore.toFixed(2)}`);
    return;
  }

  portafoglio[key] = q - 1;
  currentCredit = Number((currentCredit + valore).toFixed(2));
  aggiornaPortafoglio();
  showMessage(`Inserito €${valore.toFixed(2)}`);
}

// calcolo resto minimo (macchinetta con monete infinite) e aggiungo al portafoglio
function daiResto() {
  if (currentCredit <= 0) {
    showMessage('NO CRED.');
    return;
  }

  let resto = Number(currentCredit.toFixed(2));
  const dato = {}; // monete da dare come resto

  for (const v of MONETE) {
    const cnt = Math.floor((resto + 0.0001) / v);
    if (cnt > 0) {
      // mappa chiave come sopra
      const key = (v === 2.00) ? '2'
                : (v === 1.00) ? '1'
                : (v === 0.5) ? '0.5'
                : (v === 0.20) ? '0.2'
                : (v === 0.10) ? '0.1'
                : (v === 0.05) ? '0.05'
                : String(v);
      dato[key] = cnt;
      resto = Number((resto - cnt * v).toFixed(2));
    }
  }

  // aggiungo le monete del resto al portafoglio
  for (const k in dato) {
    portafoglio[k] = (portafoglio[k] || 0) + dato[k];
  }

  dispenserBin.textContent = `Ritira resto: €${currentCredit.toFixed(2)}`;
  dispenserBin.style.color = '#ffff00';
  showMessage(`RESTO: €${currentCredit.toFixed(2)}`, 2000);

  // reset credito dopo delay per mostrare il vano erogazione
  setTimeout(() => {
    dispenserBin.textContent = '[ Vano Erogazione ]';
    dispenserBin.style.color = 'white';
    currentCredit = 0;
    aggiornaPortafoglio();
    updateDisplay();
  }, 1500);
}

// ----- hookup: assicurati che i pulsanti .pulsante-moneta esistano -----
// usa data-valore="0.05" ecc. nel markup HTML
document.querySelectorAll('.pulsante-moneta').forEach(btn => {
  btn.addEventListener('click', () => {
    const valAttr = btn.getAttribute('data-valore');
    if (!valAttr) return;
    const valore = parseFloat(valAttr);
    inserisciMonetaByValue(valore);
  });
});

// collego RESTO e tastierino se presenti
if (coinReturnButton) coinReturnButton.addEventListener('click', daiResto);
if (keypad) {
  keypad.addEventListener('click', (ev) => {
    if (!ev.target.matches('.key')) return;
    const key = ev.target.dataset.key;
    if (key === 'C') {
      currentSelection = "";
      showMessage('ANNULL.');
    } else if (key === 'OK') {
      // processSelection deve esistere nella tua versione
      if (typeof processSelection === 'function') processSelection();
    } else {
      if (currentSelection.length < 2) currentSelection += key;
      updateDisplay();
    }
  });
}

// inizializza vista
aggiornaPortafoglio();
updateDisplay();

// ------ Fine blocco ------

});
